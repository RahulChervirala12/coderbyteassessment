# Refactoring

You've been asked to refactor the function `deterministicPartitionKey` in [`dpk.js`](dpk.js) to make it easier to read and understand without changing its functionality. For this task, you should:

1. Write unit tests to cover the existing functionality and ensure that your refactor doesn't break it. We typically use `jest`, but if you have another library you prefer, feel free to use it.
2. Refactor the function to be as "clean" and "readable" as possible. There are many valid ways to define those words - use your own personal definitions, but be prepared to defend them. Note that we do like to use the latest JS language features when applicable.
3. Write up a brief (~1 paragraph) explanation of why you made the choices you did and why specifically your version is more "readable" than the original.

You will be graded on the exhaustiveness and quality of your unit tests, the depth of your refactor, and the level of insight into your thought process provided by the written explanation.

## Your Explanation Here
1. Unit tests 
const crypto = require("crypto");
const { deterministicPartitionKey } = require("path/to/module");

describe("deterministicPartitionKey", () => {
  it("should return a string of length <= 256", () => {
    const event = {};
    const partitionKey = deterministicPartitionKey(event);
    expect(partitionKey).toBeString();
    expect(partitionKey.length).toBeLessThanOrEqual(256);
  });

  it("should return the event's partition key if it exists", () => {
    const event = { partitionKey: "my-partition-key" };
    const partitionKey = deterministicPartitionKey(event);
    expect(partitionKey).toEqual("my-partition-key");
  });

  it("should return a SHA3-512 hash of the event if no partition key exists", () => {
    const event = { data: { foo: "bar" } };
    const data = JSON.stringify(event);
    const expectedHash = crypto.createHash("sha3-512").update(data).digest("hex");
    const partitionKey = deterministicPartitionKey(event);
    expect(partitionKey).toEqual(expectedHash);
  });

  it("should return a trivial partition key if the event is falsy", () => {
    const event = null;
    const partitionKey = deterministicPartitionKey(event);
    expect(partitionKey).toEqual("O");
  });
});
2. Refactored Code

const crypto = require("crypto");

exports.deterministicPartitionKey = (event) => {
  const TRIVIAL_PARTITION_KEY = "O";
  const MAX_PARTITION_KEY_LENGTH = 256;
  let partitionKey = TRIVIAL_PARTITION_KEY;

  if (event) {
    if (event.partitionKey) {
      partitionKey = event.partitionKey;
    } else {
      const data = JSON.stringify(event);
      partitionKey = crypto.createHash("sha3-512").update(data).digest("hex");
    }
  }

  if (typeof partitionKey !== "string") {
    partitionKey = JSON.stringify(partitionKey);
  }

  if (partitionKey.length > MAX_PARTITION_KEY_LENGTH) {
    partitionKey = crypto.createHash("sha3-512").update(partitionKey).digest("hex");
  }

  return partitionKey;
};

3. Explanation of refactored code

Initializing the partitionKey variable to a trivial value and only overwriting it if a valid event is provided
Removing the check for the candidate variable and moving the logic to convert non-string values to a string to the end of the function
Renaming variables to use snake_case and consistent naming conventions