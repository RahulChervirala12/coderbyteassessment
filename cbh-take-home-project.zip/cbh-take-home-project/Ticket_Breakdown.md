# Ticket Breakdown
We are a staffing company whose primary purpose is to book Agents at Shifts posted by Facilities on our platform. We're working on a new feature which will generate reports for our client Facilities containing info on how many hours each Agent worked in a given quarter by summing up every Shift they worked. Currently, this is how the process works:

- Data is saved in the database in the Facilities, Agents, and Shifts tables
- A function `getShiftsByFacility` is called with the Facility's id, returning all Shifts worked that quarter, including some metadata about the Agent assigned to each
- A function `generateReport` is then called with the list of Shifts. It converts them into a PDF which can be submitted by the Facility for compliance.

## You've been asked to work on a ticket. It reads:

**Currently, the id of each Agent on the reports we generate is their internal database id. We'd like to add the ability for Facilities to save their own custom ids for each Agent they work with and use that id when generating reports for them.**


Based on the information given, break this ticket down into 2-5 individual tickets to perform. Provide as much detail for each ticket as you can, including acceptance criteria, time/effort estimates, and implementation details. Feel free to make informed guesses about any unknown details - you can't guess "wrong".


You will be graded on the level of detail in each ticket, the clarity of the execution plan within and between tickets, and the intelligibility of your language. You don't need to be a native English speaker, but please proof-read your work.

## Your Breakdown Here

1. Add custom agent ID field to database
2. Acceptance Criteria:
3. A new field, custom_agent_id, has been added to the Agents table in the database
4. The custom_agent_id field can store a string of up to 50 characters
5. The custom_agent_id field is nullable
Time/Effort Estimate: 2 hours
Implementation Details:
1. Use a database migration to add the custom_agent_id field to the Agents table
2. Add custom agent ID to shifts
Acceptance Criteria:
1. The Shifts table in the database has a new field, custom_agent_id, which stores the custom ID of the agent assigned to the shift
2. If an agent does not have a custom ID, the custom_agent_id field should store the internal database ID of the agent
Time/Effort Estimate: 2 hours
Implementation Details:
1. Use a database migration to add the custom_agent_id field to the Shifts table
2. Write a script to populate the custom_agent_id field for all existing shifts with the appropriate value
3. Modify `getShiftsByFacility` function to return shifts with custom agent IDs
Acceptance Criteria:
1. The `getShiftsByFacility` function returns a list of shifts with the `custom_agent_id` field populated for each shift
Time/Effort Estimate: 1 hour
Implementation Details:
1. Modify the SQL query in the `getShiftsByFacility` function to select the `custom_agent_id` field from the Shifts table in addition to the other fields
2. Return the list of shifts with the custom_agent_id field included in the shift objects
3. Modify `generateReport` function to use custom agent IDs in PDF
Acceptance Criteria:
1. The `generateReport` function generates a PDF report that displays the custom ID of each agent, if available, instead of their internal database ID
2. If an agent does not have a custom ID, the internal database ID is used instead
Time/Effort Estimate: 3 hours
Implementation Details:
1. Modify the logic in the `generateReport` function to use the custom_agent_id field in the PDF report instead of the internal database ID
2. Add UI for Facilities to set custom agent IDs
Acceptance Criteria:
1. A new page in the Facility dashboard allows Facilities to view a list of their agents and set a custom ID for each one
2. The list of agents includes their internal database ID and current custom ID (if set)
3. Facilities can edit the custom ID for an agent or remove it
4. Changes to custom IDs are saved to the database
Time/Effort Estimate: 4 hours
Implementation Details:
1. Create a new route and template for the custom ID management page in the Facility dashboard
2. Add a form to the template that allows Facilities to view and edit the custom IDs for their agents
3. Write a server-side route to handle saving changes to the custom IDs to the database